import React from 'react';
import Navbar from './Navbar';
function Homepage(){
return(
  <>
  <Navbar />
  <h1 className = "homepageHeading">Send Gifts <span>Anonymously</span></h1>
  <p className="homepagetagline">This festive season share happiness with your loved ones</p><br />
  <img src ="https://i.ibb.co/Ns1hZfb/606-removebg-preview-1.png"></img> 
  </>
  )
  
}
export default Homepage;