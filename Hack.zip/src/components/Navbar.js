import React from 'react';
import { useAuth0 } from "@auth0/auth0-react";

function Navbar(){

const { loginWithRedirect, logout  } = useAuth0();
const { user, isAuthenticated, isLoading } = useAuth0();

if (isAuthenticated){
return(
  <ul className = "Navibar">
  <li><a href="#home">Be Someone's Santa</a></li>
  
  <li style={{float:"right"}} onClick={() => loginWithRedirect()}>Login</li>
  </ul>

  )
}

else{
return(
  <ul className = "Navibar">
  <li><a class="active" href="#home">Be Someone's Santa</a></li>

  <li style={{float:"right"}}>Welcome {user}</li>
  <li style={{float:"right"}} onClick={() => logout()}>Logout</li>
  </ul>

  )
}
}
export default Navbar;